const tasks = [
  {
    id : 'T1',
    description : "manger",
    duration : 20
  },
  {
    id : 'T2',
    description : "finir le projet de JS",
    duration : 90
  },
  {
    id : 'T3',
    description : "faire une sieste",
    duration : 60
  },
  {
    id : 'T4',
    description : "prendre un café",
    duration : 5
  }
];

export default tasks;
