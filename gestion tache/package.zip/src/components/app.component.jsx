import React from 'react';
import TaskApp from './taskApp.component.jsx';

const App = () => {
  return (
    <div>
      <h1>Gestion de Taches</h1>
      <TaskApp />
    </div>
  );
};

export default App;